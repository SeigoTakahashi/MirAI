//モーダル
// モーダル表示関数
function showmodal() {
    const modal = new bootstrap.Modal(document.getElementById('eventModal'));
    modal.show();
}
